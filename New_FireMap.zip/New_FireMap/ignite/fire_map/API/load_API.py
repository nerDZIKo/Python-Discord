from fire_map.models import FireLocation
